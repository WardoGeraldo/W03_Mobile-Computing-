//
//  TH03_Edward_GApp.swift
//  TH03_Edward G
//
//  Created by student on 01/10/25.
//

import SwiftUI

@main
struct TH03_Edward_GApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
