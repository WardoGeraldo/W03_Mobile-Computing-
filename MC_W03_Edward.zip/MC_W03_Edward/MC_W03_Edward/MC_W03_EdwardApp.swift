//
//  MC_W03_EdwardApp.swift
//  MC_W03_Edward
//
//  Created by student on 25/09/25.
//

import SwiftUI

@main
struct MC_W03_EdwardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
